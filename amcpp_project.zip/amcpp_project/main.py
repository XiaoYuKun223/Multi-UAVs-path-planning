import numpy as np
import torch
import os
from planner.rapf import RAPFPlanner
from environment.uav_env import UAVEnvironment
from agent.matd3 import MATD3Agent
from utils.replay_buffer import MultiAgentReplayBuffer
from utils.plot import plot_rewards, plot_trajectories

def main():
    num_uavs = 5
    action_dim = 4
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    print("Using device:", device)

    #初始化环境
    env = UAVEnvironment(num_uavs=num_uavs)
    # 用环境返回的状态自动推导 state_dim
    states = env.reset()
    print("实际状态维度为：", states[0].shape)
    state_dim = states[0].shape[0]
    # 初始化策略、经验池
    planner = RAPFPlanner()
    agent = MATD3Agent(num_uavs, state_dim, action_dim, device=device)
    buffer = MultiAgentReplayBuffer(500000, num_uavs, state_dim, action_dim, device=device)

    max_episodes = 10000
    max_steps = 100
    batch_size = 256
    warmup = 1000
    update_every = 1

    reward_log = []
    total_steps = 0
    for ep in range(max_episodes):
        states = env.reset()
        ep_rewards = np.zeros(num_uavs)
        ep_trajectories = [[] for _ in range(num_uavs)]

        for step in range(max_steps):
            total_steps += 1
            actions = agent.select_action(states)

            forces = []
            for i in range(num_uavs):
                a = actions[i]
                planner.k_att, planner.k_rep, planner.k_in, planner.k_rot = a
                neighbors = [env.uav_pos[j] for j in range(num_uavs) if j != i]
                force = planner.compute_force(env.uav_pos[i], env.goal, env.obstacles, neighbors)
                forces.append(force)
                ep_trajectories[i].append(env.uav_pos[i].copy())

            next_states, rewards, dones = env.step(forces)
            buffer.add(states, actions, rewards, next_states, dones)
            states = next_states
            ep_rewards += rewards

            if total_steps > warmup and total_steps % update_every == 0:
                agent.update(buffer, batch_size=batch_size)

            if all(dones):
                break

        reward_log.append(np.mean(ep_rewards))
        print(f"[Episode {ep}] Avg Reward: {np.mean(ep_rewards):.2f}")

        if ep % 50 == 0 and ep > 0:
            plot_rewards(reward_log, save_path=f"logs/reward_ep{ep}.png")
            plot_trajectories(ep_trajectories, goal=env.goal, obstacles=env.obstacles)
        # 模型保存逻辑（添加 mkdir）
        if ep % 100 == 0 and ep > 0:
            os.makedirs("models", exist_ok=True)  # 创建 models 目录（若不存在）
            for i, actor in enumerate(agent.actors):
                torch.save(actor.state_dict(), f"models/actor_uav{i}.pt")
            print(f"[Saved] 模型已保存至 models/ 目录")


if __name__ == "__main__":
    main()