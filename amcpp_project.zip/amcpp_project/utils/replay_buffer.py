import numpy as np
import torch

class MultiAgentReplayBuffer:
    def __init__(self, buffer_size, n_agents, state_dim, action_dim, device='cpu'):
        self.max_size = buffer_size
        self.ptr = 0
        self.size = 0
        self.n = n_agents
        self.device = device

        self.states = [np.zeros((buffer_size, state_dim), dtype=np.float32) for _ in range(n_agents)]
        self.actions = [np.zeros((buffer_size, action_dim), dtype=np.float32) for _ in range(n_agents)]
        self.next_states = [np.zeros((buffer_size, state_dim), dtype=np.float32) for _ in range(n_agents)]
        self.rewards = [np.zeros((buffer_size,), dtype=np.float32) for _ in range(n_agents)]
        self.dones = [np.zeros((buffer_size,), dtype=np.float32) for _ in range(n_agents)]

    def add(self, state_list, action_list, reward_list, next_state_list, done_list):
        for i in range(self.n):
            self.states[i][self.ptr] = state_list[i]
            self.actions[i][self.ptr] = action_list[i]
            self.next_states[i][self.ptr] = next_state_list[i]
            self.rewards[i][self.ptr] = reward_list[i]
            self.dones[i][self.ptr] = float(done_list[i])
        self.ptr = (self.ptr + 1) % self.max_size
        self.size = min(self.size + 1, self.max_size)

    def sample(self, batch_size):
        idx = np.random.choice(self.size, size=batch_size, replace=False)
        state_batch = [torch.FloatTensor(self.states[i][idx]).to(self.device) for i in range(self.n)]
        action_batch = [torch.FloatTensor(self.actions[i][idx]).to(self.device) for i in range(self.n)]
        reward_batch = [torch.FloatTensor(self.rewards[i][idx]).to(self.device) for i in range(self.n)]
        next_state_batch = [torch.FloatTensor(self.next_states[i][idx]).to(self.device) for i in range(self.n)]
        done_batch = [torch.FloatTensor(self.dones[i][idx]).to(self.device) for i in range(self.n)]
        return state_batch, action_batch, reward_batch, next_state_batch, done_batch