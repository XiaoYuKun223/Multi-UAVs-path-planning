import matplotlib.pyplot as plt
import numpy as np
import os

def plot_rewards(reward_history, save_path=None):
    plt.figure()
    plt.plot(reward_history, label="Average Reward")
    plt.xlabel("Episode")
    plt.ylabel("Reward")
    plt.title("Training Reward Curve")
    plt.grid(True)
    plt.legend()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path)
    plt.show()

def plot_trajectories(trajectories, goal, obstacles):
    from mpl_toolkits.mplot3d import Axes3D
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    for i, traj in enumerate(trajectories):
        traj = np.array(traj)
        ax.plot(traj[:, 0], traj[:, 1], traj[:, 2], label=f'UAV {i+1}')
    for obs in obstacles:
        ax.scatter(*obs, c='red', marker='o', s=50, label='Obstacle')
    ax.scatter(*goal, c='green', marker='*', s=100, label='Goal')
    ax.set_title("UAV Flight Trajectories")
    ax.set_xlim(-1, 1)
    ax.set_ylim(-1, 1)
    ax.set_zlim(-1, 1)
    ax.legend()
    plt.show()