import os
from torch.utils.tensorboard import SummaryWriter

class Logger:
    def __init__(self, log_dir='runs', name='default'):
        self.log_path = os.path.join(log_dir, name)
        os.makedirs(self.log_path, exist_ok=True)
        self.writer = SummaryWriter(log_dir=self.log_path)
        self.ep = 0

    def log_scalar(self, key, value, step=None):
        if step is None:
            step = self.ep
        self.writer.add_scalar(key, value, step)

    def log_episode_reward(self, reward):
        self.log_scalar("Episode/Reward", reward, self.ep)

    def log_episode_length(self, length):
        self.log_scalar("Episode/Length", length, self.ep)

    def log_q_values(self, agent_id, q1, q2):
        self.log_scalar(f"Agent{agent_id}/Q1", q1, self.ep)
        self.log_scalar(f"Agent{agent_id}/Q2", q2, self.ep)

    def log_actor_loss(self, agent_id, loss):
        self.log_scalar(f"Agent{agent_id}/ActorLoss", loss, self.ep)

    def next_episode(self):
        self.ep += 1

    def close(self):
        self.writer.close()