import numpy as np

class RAPFPlanner:
    def __init__(self, k_att=1.0, k_rep=0.5, k_in=0.5, k_rot=0.3, d_goal=1.0, d_obs=0.5, d_uav=0.5):
        self.k_att = k_att
        self.k_rep = k_rep
        self.k_in = k_in
        self.k_rot = k_rot
        self.d_goal = d_goal
        self.d_obs = d_obs
        self.d_uav = d_uav

    def compute_force(self, p_uav, p_goal, obstacles, neighbors):
        F_att = self.attractive_force(p_uav, p_goal)
        F_rep = self.repulsive_force(p_uav, obstacles)
        F_in = self.inter_uav_force(p_uav, neighbors)
        F_rot = self.rotational_force(p_uav, p_goal, obstacles)
        F_res = F_att + F_rep + F_in + F_rot
        return F_res

    def attractive_force(self, p, goal):
        d = np.linalg.norm(goal - p)
        if d <= self.d_goal:
            return self.k_att * (goal - p) / self.d_goal
        else:
            return self.k_att * (goal - p)

    def repulsive_force(self, p, obstacles):
        F = np.zeros(3)
        for o in obstacles:
            d = np.linalg.norm(p - o)
            if d <= self.d_obs:
                F += self.k_rep * (1.0 / d - 1.0 / self.d_obs) * (p - o) / (d ** 3)
        return F

    def inter_uav_force(self, p, neighbors):
        F = np.zeros(3)
        for n in neighbors:
            d = np.linalg.norm(p - n)
            if d <= self.d_uav and d > 1e-3:
                F += self.k_in * (1.0 / d - 1.0 / self.d_uav) * (p - n) / (d ** 3)
        return F

    def rotational_force(self, p, goal, obstacles):
        F = np.zeros(3)
        for o in obstacles:
            d = np.linalg.norm(p - o)
            if d <= self.d_obs:
                v_goal = goal - p
                v_obs = o - p
                axis = np.cross(v_goal, v_obs)
                axis_norm = np.linalg.norm(axis)
                if axis_norm < 1e-6:
                    continue
                T = axis / axis_norm
                F += self.k_rot * (1.0 / d - 1.0 / self.d_obs) * T / (d ** 2)
        return F