import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from copy import deepcopy

class ActorNet(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, 256)
        self.out = nn.Linear(256, action_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        return torch.sigmoid(self.out(x))  # 输出系数范围 [0,1]


class CriticNet(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.fc1 = nn.Linear(state_dim + action_dim, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, 256)
        self.out = nn.Linear(256, 1)

    def forward(self, s, a):
        x = torch.cat([s, a], dim=-1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        return self.out(x)


class MATD3Agent:
    def __init__(self, n_agents, state_dim, action_dim, device='cpu',
                 actor_lr=1e-4, critic_lr=1e-3, gamma=0.95, tau=0.01):
        self.n = n_agents
        self.device = device
        self.gamma = gamma
        self.tau = tau
        self.action_dim = action_dim

        self.actors = [ActorNet(state_dim, action_dim).to(device) for _ in range(n_agents)]
        self.critics_1 = [CriticNet(state_dim * n_agents, action_dim * n_agents).to(device) for _ in range(n_agents)]
        self.critics_2 = [CriticNet(state_dim * n_agents, action_dim * n_agents).to(device) for _ in range(n_agents)]

        self.target_actors = [deepcopy(actor) for actor in self.actors]
        self.target_critics_1 = [deepcopy(critic) for critic in self.critics_1]
        self.target_critics_2 = [deepcopy(critic) for critic in self.critics_2]

        self.actor_opts = [torch.optim.Adam(actor.parameters(), lr=actor_lr) for actor in self.actors]
        self.critic_opts_1 = [torch.optim.Adam(c.parameters(), lr=critic_lr) for c in self.critics_1]
        self.critic_opts_2 = [torch.optim.Adam(c.parameters(), lr=critic_lr) for c in self.critics_2]

    def select_action(self, states):
        actions = []
        for i in range(self.n):
            s = torch.FloatTensor(states[i]).unsqueeze(0).to(self.device)
            a = self.actors[i](s)
            actions.append(a.squeeze(0).detach().cpu().numpy())
        return np.array(actions)

    def update(self, replay_buffer, batch_size=256, noise_std=0.1, noise_clip=0.2):
        samples = replay_buffer.sample(batch_size)
        states, actions, rewards, next_states, dones = samples
        for i in range(self.n):
            s_cat = torch.cat([states[j] for j in range(self.n)], dim=-1).to(self.device)
            a_cat = torch.cat([actions[j] for j in range(self.n)], dim=-1).to(self.device)
            r = rewards[i].unsqueeze(1).to(self.device)
            d = dones[i].unsqueeze(1).to(self.device)

            next_s_cat = torch.cat([next_states[j] for j in range(self.n)], dim=-1).to(self.device)
            next_a_list = []
            for j in range(self.n):
                ns = next_states[j].to(self.device)
                a = self.target_actors[j](ns)
                noise = torch.clamp(torch.randn_like(a) * noise_std, -noise_clip, noise_clip)
                a = torch.clamp(a + noise, 0.0, 1.0)
                next_a_list.append(a)
            next_a_cat = torch.cat(next_a_list, dim=-1)

            with torch.no_grad():
                q1 = self.target_critics_1[i](next_s_cat, next_a_cat)
                q2 = self.target_critics_2[i](next_s_cat, next_a_cat)
                target_q = r + self.gamma * (1 - d) * torch.min(q1, q2)

            q1_pred = self.critics_1[i](s_cat, a_cat)
            q2_pred = self.critics_2[i](s_cat, a_cat)
            loss_q1 = F.mse_loss(q1_pred, target_q)
            loss_q2 = F.mse_loss(q2_pred, target_q)

            self.critic_opts_1[i].zero_grad()
            loss_q1.backward()
            self.critic_opts_1[i].step()

            self.critic_opts_2[i].zero_grad()
            loss_q2.backward()
            self.critic_opts_2[i].step()

            if np.random.rand() < 0.5:
                a_self = self.actors[i](states[i].to(self.device))
                a_cat_new = a_cat.clone()
                a_cat_new[:, i * self.action_dim:(i + 1) * self.action_dim] = a_self
                actor_loss = -self.critics_1[i](s_cat, a_cat_new).mean()
                self.actor_opts[i].zero_grad()
                actor_loss.backward()
                self.actor_opts[i].step()
                self.soft_update(self.actors[i], self.target_actors[i])
                self.soft_update(self.critics_1[i], self.target_critics_1[i])
                self.soft_update(self.critics_2[i], self.target_critics_2[i])

    def soft_update(self, net, target_net):
        for param, target_param in zip(net.parameters(), target_net.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)