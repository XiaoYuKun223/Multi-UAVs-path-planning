import torch
import numpy as np
from planner.rapf import RAPFPlanner
from environment.uav_env import UAVEnvironment
from agent.matd3 import MATD3Agent
from utils.plot import plot_trajectories

def test_policy(agent_path=None):
    num_uavs = 5
    action_dim = 4
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    env = UAVEnvironment(num_uavs=num_uavs)

    # 用环境返回的状态自动推导 state_dim
    states = env.reset()
    print("实际状态维度为：", states[0].shape)
    state_dim = states[0].shape[0]
    planner = RAPFPlanner()
    agent = MATD3Agent(num_uavs, state_dim, action_dim, device=device)

    states = env.reset()
    trajectories = [[] for _ in range(num_uavs)]
    for _ in range(100):
        actions = agent.select_action(states)
        forces = []
        for i in range(num_uavs):
            a = actions[i]
            planner.k_att, planner.k_rep, planner.k_in, planner.k_rot = a
            neighbors = [env.uav_pos[j] for j in range(num_uavs) if j != i]
            force = planner.compute_force(env.uav_pos[i], env.goal, env.obstacles, neighbors)
            forces.append(force)
            trajectories[i].append(env.uav_pos[i].copy())
        states, _, dones = env.step(forces)
        if all(dones):
            break

    if agent_path:
        for i in range(num_uavs):
            actor_path = f"{agent_path}/actor_uav{i}.pt"
            agent.actors[i].load_state_dict(torch.load(actor_path, map_location=device))
            agent.actors[i].eval()
        print("[Loaded] 模型已从磁盘加载")

    plot_trajectories(trajectories, goal=env.goal, obstacles=env.obstacles)

if __name__ == "__main__":
    test_policy(agent_path="models")
