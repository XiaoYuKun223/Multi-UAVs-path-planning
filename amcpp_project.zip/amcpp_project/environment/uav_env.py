import numpy as np

class UAVEnvironment:
    def __init__(self, num_uavs=5, num_obs=20, space_size=2.0):
        self.num_uavs = num_uavs
        self.num_obs = num_obs
        self.space_size = space_size
        self.radius_uav = 0.02
        self.radius_obs = 0.12
        self.radius_goal = 0.13
        self.detection_range = 0.5
        self.v_scale = 0.1
        self.reset()

    def reset(self):
        self.uav_pos = np.random.uniform(-1, 1, (self.num_uavs, 3))
        self.uav_vel = np.zeros((self.num_uavs, 3))
        self.goal = np.random.uniform(-1, 1, 3)
        self.obstacles = np.random.uniform(-1, 1, (self.num_obs, 3))
        return self.get_states()

    def get_states(self):
        states = []
        for i in range(self.num_uavs):
            s_loc = np.concatenate([self.uav_pos[i], self.uav_vel[i], [self.radius_uav]])
            s_goal = np.concatenate([self.goal - self.uav_pos[i], [self.radius_goal]])
            s_uav = []
            for j in range(self.num_uavs):
                if j == i:
                    continue
                d = self.uav_pos[j] - self.uav_pos[i]
                s_uav.extend(np.concatenate([d, self.uav_vel[j], [self.radius_uav]]))
            s_obs = []
            for obs in self.obstacles:
                d = obs - self.uav_pos[i]
                dist = np.linalg.norm(d)
                if dist <= self.detection_range:
                    s_obs.extend(np.concatenate([d, [0, 0, 0], [self.radius_obs]]))
                else:
                    s_obs.extend([self.detection_range] * 3 + [0, 0, 0, 0])
            states.append(np.concatenate([s_loc, s_goal, s_uav, s_obs]))
        return np.array(states)

    def step(self, forces):
        rewards = []
        done_flags = []
        for i in range(self.num_uavs):
            f = forces[i]
            v = f / (np.linalg.norm(f) + 1e-6) * self.v_scale
            self.uav_vel[i] = v
            self.uav_pos[i] += v
            reward, done = self.get_reward(i)
            rewards.append(reward)
            done_flags.append(done)
        return self.get_states(), np.array(rewards), np.array(done_flags)

    def get_reward(self, i):
        """
        根据论文公式 4.3.2 设计的 Reward：
          R_target:    公式 (19)
          R_uav:       公式 (20)
          R_obs:       公式 (21)
        """
        p = self.uav_pos[i]
        # 1. 到目标距离 dc
        dc = np.linalg.norm(p - self.goal)

        # 公式 (19)：目标奖励
        if dc <= self.radius_uav + self.radius_goal:
            R_target = 0.0
        else:
            R_target = -dc

        # 2. UAV 间碰撞惩罚，公式 (20)
        R_uav = 0.0
        for j in range(self.num_uavs):
            if j == i: continue
            du = np.linalg.norm(p - self.uav_pos[j])
            if du <= 2 * self.radius_uav:
                R_uav += -1.0  # 多次接触累加惩罚

        # 3. 障碍物惩罚，公式 (21)
        R_obs = 0.0
        for obs in self.obstacles:
            do = np.linalg.norm(p - obs)
            # 只有在检测范围内才计算
            if do <= self.detection_range:
                # (do - ru - ro)/(drange - ru - ro) - 1
                num = do - self.radius_uav - self.radius_obs
                den = self.detection_range - self.radius_uav - self.radius_obs + 1e-6
                R_obs += num / den - 1.0

        # 总奖励 R = R_target + R_uav + R_obs
        R = R_target + R_uav + R_obs

        # 判断是否到达（dc ≤ ru + rg）作为 done 条件
        done = dc <= self.radius_uav + self.radius_goal
        return R, done

